//
//  PinAnnotation.m
//  LocationAndMap
//
//  Created by Ashraf on 3/22/20.
//  Copyright © 2020 Ashraf. All rights reserved.
//

#import "PinAnnotation.h"

@implementation PinAnnotation

@end
