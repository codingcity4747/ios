//
//  User.m
//  LocationAndMap
//
//  Created by Ashraf on 3/22/20.
//  Copyright © 2020 Ashraf. All rights reserved.
//

#import "User.h"

@implementation User

//-(id)  setName:(NSString*)name
//       setPhone:(NSString*)phone
//       setAge:(NSString*)age
//       setImage:(NSString*)image
//       setLong:(float)lon
//       setLat:(float)lat{
//
//}
@end
